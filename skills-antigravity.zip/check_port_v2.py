import socket
import requests # Menggunakan requests lebih simpel
from concurrent.futures import ThreadPoolExecutor

def get_public_ip():
    try:
        # Menggunakan api.ipify.org (TEXT ONLY), bukan ipify.org (HTML)
        response = requests.get('https://api.ipify.org', timeout=5)
        return response.text.strip()
    except:
        return None

def scan_port(host, port):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(2.0) # Ditambah sedikit agar lebih akurat
            result = s.connect_ex((host, port))
            
            try:
                service = socket.getservbyport(port)
            except:
                service = "ssh-alt" if 2200 <= port <= 2250 else "unknown"
                
            if result == 0:
                return port, "OPEN", service
            else:
                return port, "CLOSED", service
    except Exception as e:
        return port, f"ERROR ({str(e)})", "unknown"

def main():
    print("[*] Mencoba mendeteksi IP Publik Anda...")
    target = get_public_ip()
    
    if target:
        print(f"[!] Terdeteksi IP: {target}")
        confirm = input(f"[?] Apakah Anda ingin memindai IP ini? (y/n): ").lower()
        if confirm != 'y':
            target = input("[?] Masukkan IP Target yang ingin di-scan: ").strip()
    else:
        target = input("[?] Gagal deteksi otomatis. Masukkan IP Target: ").strip()

    # Port yang ingin dicek
    specific_ports = [22, 25, 80, 443, 2222]
    ssh_range = list(range(2200, 2210)) # Kita cek 10 port saja untuk tes awal
    all_ports = sorted(list(set(specific_ports + ssh_range)))

    print(f"\n[*] Memulai pemindaian pada: {target}")
    print("="*40)
    
    open_count = 0
    with ThreadPoolExecutor(max_workers=20) as executor:
        futures = [executor.submit(scan_port, target, p) for p in all_ports]
        for f in futures:
            port, status, service = f.result()
            if status == "OPEN":
                print(f"[+] PORT {port:<5} : {status} ({service})")
                open_count += 1
            else:
                print(f"[-] PORT {port:<5} : {status}")

    print("="*40)
    print(f"Selesai! Port Terbuka: {open_count}")

if __name__ == "__main__":
    # Pastikan library requests terinstal: pip install requests
    main()
