import socket
import urllib.request
from concurrent.futures import ThreadPoolExecutor

def get_dynamic_ip():
    try:
        return urllib.request.urlopen('https://ipify.org', timeout=5).read().decode('utf8')
    except:
        return None

def scan_port(host, port):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1.5)
            result = s.connect_ex((host, port))
            # Mencoba mendapatkan nama service
            try:
                service = socket.getservbyport(port)
            except:
                service = "ssh-alt" if 2200 <= port <= 2250 else "unknown"
                
            if result == 0:
                return port, "OPEN", service
            else:
                return port, "CLOSED/FILTERED", service
    except:
        return port, "ERROR", "unknown"

def main():
    target = get_dynamic_ip()
    if not target:
        target = input("[?] Masukkan/Paste IP Target: ").strip()

    specific_ports = [80, 443, 465, 587, 993, 143, 110, 995, 25, 22]
    ssh_range = list(range(2200, 2251))
    all_ports = sorted(list(set(specific_ports + ssh_range)))

    print(f"[*] Memindai {target}...")
    
    scan_results = []
    with ThreadPoolExecutor(max_workers=50) as executor:
        futures = [executor.submit(scan_port, target, p) for p in all_ports]
        for f in futures:
            scan_results.append(f.result())

    # --- PROSES SIMPAN KE MARKDOWN ---
    filename = "hasil_scan_port.md"
    with open(filename, "w") as f:
        f.write(f"# Hasil Pemindaian Port - {target}\n\n")
        f.write(f"| Port | Status | Service |\n")
        f.write(f"| :--- | :--- | :--- |\n")
        
        open_count = 0
        for port, status, service in scan_results:
            f.write(f"| {port} | {status} | {service} |\n")
            if status == "OPEN":
                open_count += 1
                print(f"[+] Port {port} ditemukan TERBUKA")

    print("-" * 40)
    print(f"Selesai! {len(scan_results)} port telah diperiksa.")
    print(f"Port Terbuka: {open_count}")
    print(f"Hasil lengkap disimpan di: {filename}")

if __name__ == "__main__":
    main()
