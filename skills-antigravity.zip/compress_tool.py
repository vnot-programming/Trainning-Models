import os
import zipfile
import shutil
from datetime import datetime

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header():
    print("="*60)
    print("        ANTIGRAVITY FILE & FOLDER COMPRESSOR v1.0")
    print("="*60)

def get_valid_path(prompt):
    while True:
        path = input(prompt).strip().strip('"').strip("'")
        if os.path.exists(path):
            return path
        print(f"❌ Error: Path tidak ditemukan: {path}")
        if input("Coba lagi? (y/n): ").lower() != 'y':
            return None

def compress_items(item_list, output_filename):
    print(f"\n📦 Memulai proses kompresi ke: {output_filename}...")
    try:
        with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for item in item_list:
                if os.path.isfile(item):
                    # Menambahkan file ke root zip
                    zipf.write(item, os.path.basename(item))
                    print(f"✅ Menambahkan file: {os.path.basename(item)}")
                elif os.path.isdir(item):
                    # Menambahkan folder beserta isinya
                    base_dir = os.path.basename(item)
                    for root, dirs, files in os.walk(item):
                        for file in files:
                            file_path = os.path.join(root, file)
                            # Membuat arcname agar struktur folder terjaga
                            arcname = os.path.join(base_dir, os.path.relpath(file_path, item))
                            zipf.write(file_path, arcname)
                    print(f"✅ Menambahkan folder: {base_dir}")
        return True
    except Exception as e:
        print(f"❌ Terjadi kesalahan saat kompresi: {str(e)}")
        return False

def main():
    targets = []
    
    while True:
        clear_screen()
        print_header()
        
        if targets:
            print("\n📋 List item yang akan dikompres:")
            for i, t in enumerate(targets, 1):
                print(f"   {i}. [{ 'FOLDER' if os.path.isdir(t) else 'FILE  ' }] {t}")
            print("-" * 30)

        print("\nPilih opsi:")
        print("1. Tambah File")
        print("2. Tambah Folder")
        print("3. Selesai & Kompres")
        print("4. Keluar")
        
        choice = input("\nMasukkan pilihan (1-4): ")

        if choice == '1':
            path = get_valid_path("📄 Paste path FILE: ")
            if path and os.path.isfile(path):
                if path not in targets: targets.append(path)
            elif path:
                print("❌ Itu bukan file!")
                input("Tekan Enter...")
                
        elif choice == '2':
            path = get_valid_path("📁 Paste path FOLDER: ")
            if path and os.path.isdir(path):
                if path not in targets: targets.append(path)
            elif path:
                print("❌ Itu bukan folder!")
                input("Tekan Enter...")

        elif choice == '3':
            if not targets:
                print("⚠️ List masih kosong! Tambahkan file atau folder terlebih dahulu.")
                input("Tekan Enter...")
                continue
            break
            
        elif choice == '4':
            print("👋 Keluar dari program.")
            return

    # Proses Kompresi
    temp_zip = f"archive_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
    if compress_items(targets, temp_zip):
        print("\n✨ Kompresi selesai di folder temporary.")
        
        # Penempatan File Akhir
        while True:
            dest_dir = input("\n📍 Dimana file kompresi akan disimpan? (Paste path folder): ").strip().strip('"').strip("'")
            
            if not os.path.exists(dest_dir):
                try:
                    os.makedirs(dest_dir)
                    print(f"📂 Folder tujuan dibuat: {dest_dir}")
                except:
                    print("❌ Gagal membuat folder tujuan. Masukkan path yang valid.")
                    continue
            
            final_name = input("💾 Beri nama file (contoh: hasil_backup.zip): ").strip()
            if not final_name.endswith('.zip'):
                final_name += '.zip'
                
            final_path = os.path.join(dest_dir, final_name)
            
            try:
                shutil.move(temp_zip, final_path)
                print("\n" + "="*60)
                print(f"🚀 SUCCESS!")
                print(f"📍 Lokasi Penyimpanan: {os.path.abspath(final_path)}")
                print(f"📦 Ukuran File: {os.path.getsize(final_path) / 1024:.2f} KB")
                print("="*60)
                break
            except Exception as e:
                print(f"❌ Gagal memindahkan file: {str(e)}")
                if input("Coba lagi lokasi lain? (y/n): ").lower() != 'y':
                    print(f"⚠️ File tetap berada di lokasi script sebagai: {temp_zip}")
                    break

if __name__ == "__main__":
    main()
