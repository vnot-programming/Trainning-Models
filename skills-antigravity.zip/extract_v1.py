import os
import zipfile
import tarfile
from pathlib import Path

def print_header():
    print("\n" + "="*50)
    print(" 📦  ADVANCED FILE EXTRACTOR (2026 Edition)")
    print("="*50 + "\n")

def get_valid_file():
    while True:
        file_path = input("📂 Paste the path of the compressed file: ").strip().strip("'").strip('"')
        path = Path(file_path)
        
        if path.is_file():
            # Check supported extensions
            supported = ('.zip', '.tar', '.gz', '.tgz', '.bz2', '.tbz2', '.xz')
            if any(file_path.lower().endswith(ext) for ext in supported):
                return path
            else:
                print("❌ Unsupported file format. Use: .zip, .tar, .tar.gz, .tar.bz2, etc.")
        else:
            print(f"❌ File not found: {file_path}")

def get_destination(source_path):
    print(f"\n📍 Source directory: {source_path.parent}")
    choice = input("❓ Extract in the same location? (y/n): ").lower().strip()
    
    if choice == 'y' or choice == '':
        return source_path.parent
    else:
        while True:
            dest_path = input("🎯 Paste the destination path: ").strip().strip("'").strip('"')
            dest = Path(dest_path)
            
            # Create directory if it doesn't exist
            try:
                dest.mkdir(parents=True, exist_ok=True)
                return dest
            except Exception as e:
                print(f"❌ Could not create/access directory: {e}")

def extract_file(source, destination):
    print(f"\n🚀 Extracting to: {destination}...")
    
    try:
        if source.suffix.lower() == '.zip':
            with zipfile.ZipFile(source, 'r') as zip_ref:
                zip_ref.extractall(destination)
        elif '.tar' in source.name.lower() or source.suffix.lower() in ['.tgz', '.tbz2']:
            # Automatically handles gz, bz2, and xz if mode is 'r:*'
            with tarfile.open(source, 'r:*') as tar_ref:
                tar_ref.extractall(destination)
        else:
            print("❌ Unexpected file type during extraction.")
            return False
            
        print("✅ Extraction completed successfully!")
        return True
    except Exception as e:
        print(f"💥 Error during extraction: {e}")
        return False

def main():
    try:
        print_header()
        source = get_valid_file()
        dest = get_destination(source)
        extract_file(source, dest)
        print("\n✨ Done.")
    except KeyboardInterrupt:
        print("\n\n👋 Operation cancelled by user.")
    except Exception as e:
        print(f"\n⚠️ An unexpected error occurred: {e}")

if __name__ == "__main__":
    main()
