import socket
import sys

def test_ports(port_list):
    print("="*50)
    print(" AUDIT PORT INBOUND VPS ")
    print("="*50)
    print("Skrip ini akan mencoba membuka socket di port berikut.")
    print("Gunakan layanan seperti 'portchecktool.com' atau 'telnet'")
    print("dari komputer luar untuk mengecek apakah port ini TERBUKA.\n")

    for port in port_list:
        try:
            # Membuat socket TCP
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            
            # Mencoba mengikat ke IP 0.0.0.0 (semua interface)
            sock.bind(('0.0.0.0', port))
            sock.listen(1)
            sock.settimeout(5)
            
            print(f"[✅] PORT {port:<5} : BERHASIL LISTENING. Silakan cek dari luar.")
            
            # Kita tidak perlu accept koneksi, hanya memastikan bisa bind.
            sock.close()
        except PermissionError:
            print(f"[❌] PORT {port:<5} : GAGAL (Permission Denied). Harus lari sebagai sudo/root.")
        except OSError as e:
            print(f"[⚠️] PORT {port:<5} : GAGAL (Mungkin sedang digunakan aplikasi lain).")
        except Exception as e:
            print(f"[?] PORT {port:<5} : ERROR - {e}")

# Daftar port "Sangat Penting" yang sering diblokir Azure/ISP
# 25: SMTP (Hampir selalu diblokir Azure)
# 80/443: Web (Biasanya terbuka)
# 2222: Common Proxy/Alt SSH
# 3389: RDP
# 25565: Game Server (Minecraft)
# 8000/8080: Dev Server
important_ports = [25, 80, 443, 2222, 3306, 3389, 5432, 8000, 8080, 25565]

if __name__ == "__main__":
    if len(sys.argv) > 1:
        # Jika user ingin nambah port custom lewat argumen
        custom_ports = [int(p) for p in sys.argv[1:]]
        test_ports(custom_ports)
    else:
        test_ports(important_ports)
